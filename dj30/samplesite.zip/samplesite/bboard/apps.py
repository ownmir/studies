from django.apps import AppConfig


class BboardConfig(AppConfig):
    name = 'bboard'
