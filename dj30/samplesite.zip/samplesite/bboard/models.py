from django.db import models
# Стр 444
from django.contrib.auth.models import User

# Create your models here.
class Bb(models.Model):
    title = models.CharField(max_length=50, verbose_name='Товар')
    content = models.TextField(null=True, blank=True, verbose_name='Описание')
    price = models.FloatField(null=True, blank=True, verbose_name='Цена')
    published = models.DateTimeField(auto_now_add=True, db_index=True, verbose_name='Опубликовано')
    rubric = models.ForeignKey('Rubric', null=True, on_delete=models.PROTECT, verbose_name = 'Рубрика')  # Стр 55 связь "один-со-многими" - 1 запись рубрики (первичной модели) будет связана с произвольным количеством  записей объявлений (вторичной)
    
    class Meta:
        verbose_name_plural = 'Объявления'
        verbose_name='Объявление'
        ordering = ['-published']

class Rubric(models.Model):
    """Стр 54 Тематические рубрики"""
    name = models.CharField(max_length=20, db_index=True, verbose_name='Название')
    
    def __str__(self):
        return self.name
    
    class Meta:
        verbose_name_plural = 'Рубрики'
        verbose_name = 'Рубрика'
        ordering = ['name']

# Стр 444
class Profile(models.Model):

    status = models.CharField(max_length=4, choices=(('Busy','Busy',), ('Free', 'Free',)), default='Busy', verbose_name="Статус")
    user = models.OneToOneField(User, on_delete=models.CASCADE, verbose_name="Користувач")
    
    def __str__(self):
        return f'{self.user.get_full_name()} - {self.status}'
    
    class Meta:
        verbose_name = 'Профиль'
        verbose_name_plural = 'Профили'
        
