from .models import Rubric, Profile
from rest_framework import serializers


class RubricSerializer(serializers.ModelSerializer):
    class Meta:
        model = Rubric
        fields = ('id', 'name')

class ProfileSerializer(serializers.ModelSerializer):
    status = serializers.ChoiceField(choices=('Busy', 'Free',))
    # auth = serializers.BooleanField(required=False, default=False)

    class Meta:
        model = Profile
        fields = ('id', 'status', 'user_id')
