from django.urls import path

from .views import index, by_rubric, BbCreateView, BbDetailView, BbIndexView, rubrics_api, web_rubrics_api, \
    profiles_api, user_api_profile, detail_api_rubric, public_detail_api_profile

urlpatterns = [
    path('add/', BbCreateView.as_view(), name='add'),
    path('<int:rubric_id>/', by_rubric, name='by_rubric'),
    path('detail/<int:pk>/', BbDetailView.as_view(), name='detail'),
    path('years/', BbIndexView.as_view(), name='years'),
    path('', index, name='index'),
    path('api/rubrics/<int:pk>/', detail_api_rubric),
    path('api/profiles/public/', public_detail_api_profile),
    path('api/profiles/<int:pk>/', user_api_profile),
    path('api/rubrics/', rubrics_api, name='rubrics_api'),
    path('api/profiles/', profiles_api, name='profiles_api'),
    path('api/rubrics/web/', web_rubrics_api, name='web_rubrics_api'),
    ]
