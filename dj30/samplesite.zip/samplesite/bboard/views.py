from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from django.template import loader
# Стр 63
from django.views.generic.edit import CreateView
from .forms import BbForm
# Стр 65
from django.urls import reverse_lazy

from .models import Bb, Rubric
# Стр 204
from django.views.generic.detail import DetailView
# Стр 219
from django.views.generic.dates import ArchiveIndexView
# Стр 537
from .serializers import RubricSerializer
# Стр 538
from rest_framework.response import Response
from rest_framework.decorators import api_view

# Create your views here. Стр 44
# def index(request):
    # template = loader.get_template('bboard/index.html')
    # bbs = Bb.objects.order_by('-published')
    # # s += bb.title + '\r\n' + bb.content + '\r\n\r\n' # Стр. 42 Список объявлений мы представили в виде обычного текста, разбитого на строки символами \r\n.
    # context = {'bbs': bbs}
    # return HttpResponse(template.render(context, request))

# Стр 46
# def index(request):
    ## template = loader.get_template('bboard/index.html')
    # bbs = Bb.objects.order_by('-published')
    # return render(request, 'bboard/index.html', {'bbs': bbs})

# Стр 59
def index(request):
    bbs = Bb.objects.all()
    rubrics = Rubric.objects.all()
    context = {'bbs': bbs, 'rubrics': rubrics}
    return render(request, 'bboard/index.html', context)

# Стр 58
def by_rubric(request, rubric_id):
    bbs = Bb.objects.filter(rubric=rubric_id)
    rubrics = Rubric.objects.all()
    current_rubric = Rubric.objects.get(pk=rubric_id)
    context = {'bbs': bbs, 'rubrics': rubrics, 'current_rubric': current_rubric}
    return render(request, 'bboard/by_rubric.html', context)

# Стр 63
class BbCreateView(CreateView):
    template_name = 'bboard/create.html'
    form_class = BbForm
    # success_url = '/bboard/'
    success_url = reverse_lazy('index')  # Стр 65
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['rubric'] = Rubric.objects.all()
        return context

# Стр 205
class BbDetailView(DetailView):
    model = Bb
        
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['rubrics'] = Rubric.objects.all()
        return context

# Стр 219
class BbIndexView(ArchiveIndexView):
    model = Bb
    date_field = "published"
    date_list_period = "year"
    template_name = "bboard/index.html"
    context_object_name = "bbs"
    allow_empty = True
    
    def get_context_data(self, *args, **kwargs):
        context = super().get_context_data(*args, **kwargs)
        context['rubrics'] = Rubric.objects.all()
        context['slug_example'] = 'Trans to slug'
        return context

# Стр 537
def rubrics_api(request):
    if request.method == 'GET':
        rubrics = Rubric.objects.all()
        serializer = RubricSerializer(rubrics, many=True)
        return JsonResponse(serializer.data, safe=False)

# Стр 538
@api_view(['GET'])
def web_rubrics_api(request):
    if request.method == 'GET':
        rubrics = Rubric.objects.all()
        serializer = RubricSerializer(rubrics, many=True)
        return Response(serializer.data)

# Стр 541
@api_view(['GET'])
def detail_api_rubric(request, pk):
    if request.method == 'GET':
        rubric = Rubric.objects.get(pk=pk)
        serializer = RubricSerializer(rubric)
        return Response(serializer.data)
