function fun1() {
  var rad=document.getElementsByName('r1');
  for (var i=0;i<rad.length; i++) {
    if (rad[i].checked) {
      alert('������ '+i+' radiobutton');
    }
  }
}
//fun1();
