﻿// Стр 540 перечень рубрик на фронте
const domain = 'http://localhost:8000/bboard/';
let list = document.getElementById('list');
let listLoader = new XMLHttpRequest();
listLoader.addEventListener('readystatechange', () => {
    if (listLoader.readyState == 4) {
        if (listLoader.status == 200) {
            let data = JSON.parse(listLoader.responseText);
            // window.alert(data);
            let s = '<ul>', d;
            for (let i = 0; i < data.length; i++) {
                d = data[i];
				// Стр 542 ссылка Вывести на фронте, стр 546 ссылка Удалить
                // Выводим рядом с названием каждой рубрики ссылку на сведения о рубрике  и ссылку Удалить
                // Привязали к каждой ссылке класс detail
                // Записали интернет адреса для загрузки рубрик в тегах a
                s += '<li>' + d.name + ' <a href="' + domain +
                    'api/rubrics/' + d.id +
                    '/" class="detail">Вывести</a> <a href="' + domain + 
					'api/rubrics/' + d.id + 
					'/" class="delete">Удалить</a></li>';
                // s += '<li>' + d.name + '</li>';
            }
            s += '</ul>';
            list.innerHTML = s;
            // Мы привязали к каждой ссылке обработчик события click
            let links = list.querySelectorAll('ul li a.detail');
            links.forEach((link) =>
            {link.addEventListener('click', rubricLoad);});
			// привязка к ссылке Удалить
			links = list.querySelectorAll('ul li a.delete');
			links.forEach((link) => 
				{link.addEventListener('click', rubricDelete);});
        } else
            window.alert(listLoader.statusText);
    }
}) ;
function listLoad() {
    listLoader.open('GET', domain + 'api/rubrics/', true);
    listLoader.send();
}
// Стр 542, 543 вывод названия рубрики
let id = document.getElementById('id');
let name = document.getElementById('name');
let rubricLoader = new XMLHttpRequest();

rubricLoader.addEventListener('readystatechange', () =>{
    if (rubricLoader.readyState == 4) {
        if (rubricLoader.status == 200) {
            let data = JSON.parse(rubricLoader.responseText);
            id.value = data.id;
            name.value = data.name;
        } else
            window.alert(rubricLoader.statusText);
    }
});

/*
Функция rubricLoad - обработчик события click ссылок <b>Вывести<b> - извлекает из ...
*/
function rubricLoad(evt) {
    evt.preventDefault();
	// ...                   атрибута   href тега <a> ссылки, на которой был выполнен клик мышкой, инет-адрес
    rubricLoader.open('GET', evt.target.href, true);  // и запускает процесс загрузки с этого адреса сведений о рубрике. 
	// Полученные сведения - название рубрики - выводятся в веб-форме.
    rubricLoader.send();
}
// Стр 545 Создание и правка рубрик на фронте
let rubricUpdater = new XMLHttpRequest();
rubricUpdater.addEventListener('readystatechange', () => {
	if (rubricUpdater.readyState == 4) {
		if ((rubricUpdater.status == 200) || 
			(rubricUpdater.status == 201)) {  // успешное исправление или добавление (201) рубрики
			listLoad();  // обновляем перечень рубрик
			name.form.reset();  // очищаем форму
			id.value = '';  // заносим в скрытое поле пустую строку
		} else
			window.alert(rubricUpdater.statusText);
	}
}
);
name.form.addEventListener('submit', (evt) => {
	evt.preventDefault();
	let vid = id.value, url, method;
	if (vid) {  // проверяем, хранится ли в скрытом поле id ключ рубрики
		// скрытое поле хранит ключ, значит, выполняется правка уже имеющейся рубрики
		url = 'api/rubrics/' + vid + '/';  // вычисляется инет-адрес
		method = 'PUT';  //  
	} else {
		// в список добавляется новая рубрика
		url = 'api/rubrics/';  // вычисляется инет-адрес
		method = 'POST';  // 
	}
	// Введенные в форму данные кодируются в формат json 
	let data = JSON.stringify({id: vid, name: name.value});
	rubricUpdater.open(method, domain + url, true);
	rubricUpdater.setRequestHeader('Content-Type', 'application/json');  // в заголовке Content-Type указывается application/json, чтобы rest_framework подобрала подходящий парсер
	rubricUpdater.send(data);
}
);

// Удаление рубрик
let rubricDeleter = new XMLHttpRequest();
rubricDeleter.addEventListener('readystatechange', () => {
	if (rubricDeleter.readyState == 4) {
		if (rubricDeleter.status == 204)
			listLoad();
		else
			window.alert(rubricDeleter.statusText);
	}
});

function rubricDelete(evt) {
	evt.preventDefault();
	rubricDeleter.open('DELETE', evt.target.href, true);
	rubricDeleter.send();
}

listLoad();
