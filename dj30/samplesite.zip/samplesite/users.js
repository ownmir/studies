﻿// Статусы публичного пользователя и вошедшего пользователя на фронте
const domain = 'http://localhost:8000/bboard/';
// 1 посмотреть статус пользователя public
let publicStatus = document.getElementsByName('publicStatus');  // радио публичного пользователя

let publicStatusLoader = new XMLHttpRequest();
publicStatusLoader.addEventListener('readystatechange', () => {
    if (publicStatusLoader.readyState == 4) {
        if (publicStatusLoader.status == 200) {
            let data = JSON.parse(publicStatusLoader.responseText);
            // window.alert(data.status);
			if (data.status == 'Busy') {
				publicStatus[0].checked = true;
			} else
				publicStatus[1].checked = true;

        } else
            window.alert(publicStatusLoader.statusText);
    }
}) ;
function publicLoad() {
	publicStatusLoader.open('GET', domain + 'api/profiles/public/', false);
	publicStatusLoader.send();
}
// 2 если пользователь зарегистрирован посмотреть статус этого пользователя  ...
let id = document.getElementById('id');
let userStatus = document.getElementsByName('userStatus');
let user_id = document.getElementById('user_id');
let userStatusLoader = new XMLHttpRequest();
let info = document.getElementById('info');
let formStatus = document.getElementById('status_form');
userStatusLoader.addEventListener('readystatechange', () => {
    if (userStatusLoader.readyState == 4) {
        if (userStatusLoader.status == 200) {
            let data = JSON.parse(userStatusLoader.responseText);
			if (data.auth) {
				info.hidden = 'hidden';
			} else
				formStatus.hidden = 'hidden';
			id.value = data.id;
			if (data.status == 'Busy') {
				userStatus[0].checked = true;
			} else
				userStatus[1].checked = true;
			user_id.value = data.user_id;

        } else
			window.alert(userStatusLoader.statusText);
    }
}) ;
function userLoad() {
	userStatusLoader.open('GET', domain + 'api/profiles/1/', false);
	userStatusLoader.send();
}
// ... 3 иметь возможность поменять этот статус (Busy/Free)
// Правка статуса вошедшего на фронте
let profileUpdater = new XMLHttpRequest();
profileUpdater.addEventListener('readystatechange', () => {
	if (profileUpdater.readyState == 4) {
		if (profileUpdater.status == 200) {  // успешное исправление статуса
			userLoad();  // обновляем текущий статус
			publicLoad();  // нужно, если вошедший совпадает с публичным
		} else
			window.alert(userStatusLoader.statusText);
	}
}
);
userStatus[0].form.addEventListener('submit', (evt) => {
	evt.preventDefault();
	
	let vid = id.value, url, method;
	// window.alert(vid)
	if (vid) {  // проверяем, хранится ли в скрытом поле id ключ
		url = 'api/profiles/' + vid + '/';  // вычисляется инет-адрес
		method = 'PUT';  //  
	}
	let statusValue;
	if (userStatus[0].checked) {statusValue = 'Busy'}
	if (userStatus[1].checked) {statusValue = 'Free'}
	// Введенные в форму данные кодируются в формат json 
	let data = JSON.stringify({id: vid, status: statusValue, user_id: user_id.value});
	profileUpdater.open(method, domain + url, true);
	profileUpdater.setRequestHeader('Content-Type', 'application/json');  // в заголовке Content-Type указывается application/json, чтобы rest_framework подобрала подходящий парсер
	profileUpdater.send(data);
}
);

publicLoad();
userLoad();
